#RCODE ASSIGNMENT REPORT ONE

#install.packages("RODBC")
require(RODBC)
#install.packages("zoom")
library(zoom)
#install.packages("dplyr")
library(dplyr)
#install.packages("tidyr")
library(tidyr)
#install.packages("reshape2")
library(reshape2)
library(randomcoloR)
#zm()
#creaing connection
conn = odbcDriverConnect('driver={SQL Server};server=.\\SQLEXPRESS;
                         database=SakilaDBS; trusted_connection=true;')
conn

############################## available movies by actors ################################################
#bar plot
queryMoviesByAcctor ="select da.ACTORNAME ,count(da.MOVIEID) as TOTLMOVIESBYACTOR
from DIM_ACTOR da
GROUP BY DA.ACTORNAME"

MoviesByActorData =sqlQuery(conn, queryMoviesByAcctor)
summary(data.frame(MoviesByActorData))
length(MoviesByActorData$TOTLMOVIESBYACTOR)



n <- length(MoviesByActorData$ACTORNAME)
palette <- distinctColorPalette(n)

#limiting xlim = 50 bins
barplot(MoviesByActorData$TOTLMOVIESBYACTOR, main= "Available No of Movies by Actor",
        ylab="Number of Movies",
        xlab="Actor Names",
        col= palette,
        names.arg = MoviesByActorData$ACTORNAME,
        cex.axis = 1,
        cex.names = 0.6,
        horiz = FALSE,
        las= 2,
        ylim = c(0,60),
        xlim = c(0,50)
        
        )

zm()

#install.packages("ggplot")

######################################### 2.total dvds by actor ############
#bar plots
queryActorDvdCounts = "SELECT da.ACTORNAME, count(dd.DVDID) AS TOTALDVDS
from DIM_ACTOR da
                    inner join DIM_MOVIE dm
                    on dm.MOVIEID = da.MOVIEID
                    inner join DIM_DVD dd
                    on dd.MOVIEID = dm.MOVIEID
                    group by da.ACTORNAME
                    order by da.ACTORNAME"


dataActorDvdCounts= sqlQuery(conn, queryActorDvdCounts)
summary(data.frame(dataActorDvdCounts))

#length(MoviesByActorData$TOTLMOVIESBYACTOR)

barplot(dataActorDvdCounts$TOTALDVDS, main= " No of DVDS by Actor",
        ylab="NO OF DVDS",
        xlab="Actor Names",
        col= palette,
        names.arg = dataActorDvdCounts$ACTORNAME,
        cex.axis = 1,
        cex.names = 0.6,
        horiz = FALSE,
        las= 2,
        xlim = c(0,50)
        
)
zm()

########################################################## 3.earnings by date #####
library(ggplot2)
theme_set(theme_minimal())

querySTring = "select dd.FullDate, sum(fr.DOLLARRENT) as EARNINGRENT
 from FACT_REVENUE fr
 inner join DIM_DATE dd
 on dd.DATEKEY= fr.DATEKEY
 group by dd.FullDate
"
data = sqlQuery(conn, querySTring)

# Basic line plot
ggplot(data = data, aes(x = FullDate, y = EARNINGRENT, group = 1))+
  geom_line(color = "#00FF00", size = 2)+
theme(plot.title = element_text(hjust = 0.5),axis.text.x = element_text(angle = 90, hjust = 1))+
  labs(title="Earnings By Date",x ="Date", y = "Earnings")

# Plot a subset of the data
zm()

############################## 4.RENT EARNED BY DATE AND CATEGORY ###################

# qrySTring = "select  dd.full, dc.CATEGORYNAME, sum(fr.DOLLARRENT) as RENTEARNED
#  from FACT_REVENUE fr
#  inner join DIM_DATE dd
#  on dd.DATEKEY= fr.DATEKEY
#  inner join DIM_CATEGORY dc
#  on dc.CATEGORYKEY = fr.CATEGORYKEY
#  group by dd.Month_, dd.Year_, dc.CATEGORYNAME
# "

data = sqlQuery(conn, "select  dd.Month_, dc.CATEGORYNAME, sum(fr.DOLLARRENT) as RENTEARNED
 from FACT_REVENUE fr
                inner join DIM_DATE dd
                on dd.DATEKEY= fr.DATEKEY
                inner join DIM_CATEGORY dc
                on dc.CATEGORYKEY = fr.CATEGORYKEY
                group by dd.Month_, dc.CATEGORYNAME
                ")

ggplot(data, aes(x = Month_, y = RENTEARNED)) +
  geom_area(aes(color = CATEGORYNAME, fill = CATEGORYNAME),
            alpha = 0.5, position = position_dodge(0.8)) +
  scale_color_manual(values = palette) +
  scale_fill_manual(values = palette)+
theme(plot.title = element_text(hjust = 0.5),axis.text.x = element_text(angle = 90, hjust = 1))+
  labs(title="Monthly Earnings By Category",x ="Month", y = "Earnings")
zm()
