use sakila
USE SakilaDBS

CREATE TABLE DIM_REGION
( 
REGIONKEY  INT IDENTITY(1,1) NOT NULL,

CITY NVARCHAR(255) NOT NULL ,

COUNTRY NVARCHAR(255) ,

CONSTRAINT PK_DIM_REGION PRIMARY KEY (REGIONKEY)

);


drop table dim_customers
CREATE TABLE DIM_CUSTOMERS
( 
CUSTOMERKEY  INT IDENTITY(1,1) NOT NULL,
CUTOMERID INT NOT NULL,
CUSTOMERNAME NVARCHAR(255) NOT NULL ,

CITY NVARCHAR(255) ,

COUNTRY NVARCHAR(255) ,

CONSTRAINT PK_DIM_CUSTOMERS PRIMARY KEY (CUSTOMERKEY)

);

DBCC CHECKIDENT ('[DIM_ACTOR]', RESEED, 1)  
CREATE TABLE DIM_DATE
(
DATEKEY INT  IDENTITY(1,1) NOT NULL, 
[FullDate] [date] NULL,
[DayofWeek_] NVARCHAR(15) NULL,
[DayType] NVARCHAR(20) NULL,
[DayofMonth_] [int] NULL,
[Month_] NVARCHAR(10) NULL,
[Quarter_] NVARCHAR(2) NULL,
[Year_] [int] NULL,

CONSTRAINT PK_DIM_DATE PRIMARY KEY (DATEKEY)

);

CREATE TABLE DIM_MOVIE
(
MOVIEKEY INT IDENTITY(1,1) NOT NULL,
MOVIEID INT NOT NULL,
MOVIENAME NVARCHAR(255),
RELEASEYEAR DATE,
MOVIELENGTH INT,
RATING NVARCHAR(5),
CATEGORY NVARCHAR(100)

CONSTRAINT PK_DIM_MOVIE PRIMARY KEY (MOVIEKEY)
);

CREATE TABLE DIM_RENTAL
(
RENTALKEY INT IDENTITY(1,1),
RENTALID INT NOT NULL,
MOVIEID INT NOT NULL,
CUSTOMERID INT NOT NULL,
RENTEDDATE DATE,
RETURNDATE DATE,
PAYMENTDATE DATE,
RENTAMOUNT MONEY
CONSTRAINT PK_DIM_RENTAL PRIMARY KEY (RENTALKEY)
);
DROP TABLE DIM_ACTOR
CREATE TABLE DIM_ACTOR
(
ACTORKEY INT IDENTITY(1,1) NOT NULL,
ACTORID INT NOT NULL,
ACTORNAME NVARCHAR(255) NOT NULL,
MOVIEID INT NOT NULL,
MOVIENAME NVARCHAR(255) NOT NULL,

CONSTRAINT PK_DIM_ACTOR PRIMARY KEY(ACTORKEY)
);
DROP TABLE DIM_CATEGORY
CREATE TABLE DIM_CATEGORY
(
CATEGORYKEY INT IDENTITY(1,1) NOT NULL, 
CATEGORYNAME NVARCHAR(255) NOT NULL,

CONSTRAINT PK_DIM_CATEGORY PRIMARY KEY(CATEGORYKEY)
);

USE SakilaDBS
CREATE TABLE DIM_DVD
(
DVDKEY INT IDENTITY(1,1), --INVENTORY KEY
DVDID INT NOT NULL, --INVENTORYID
MOVIEID INT NOT NULL
CONSTRAINT PK_DIM_DVD PRIMARY KEY(DVDKEY) 

);

USE SakilaDBS
DROP TABLE FACT_REVENUE
CREATE TABLE FACT_REVENUE
(
MOVIEKEY INT NOT NULL,
DVDKEY INT NOT NULL,
CATEGORYKEY INT NOT NULL,
REGIONKEY INT NOT NULL,
DATEKEY INT NOT NULL,
DOLLARRENT MONEY,
--COUNT_RENTED INT,


CONSTRAINT FK_DIM_REVENUE_MOVIE FOREIGN KEY(MOVIEKEY) REFERENCES  DIM_MOVIE (MOVIEKEY)
ON DELETE NO ACTION,

CONSTRAINT FK_DIM_REVENUE_DVD FOREIGN KEY(DVDKEY) REFERENCES  DIM_DVD (DVDKEY)
ON DELETE NO ACTION,

CONSTRAINT FK_DIM_REVENUE_CATEGRY FOREIGN KEY(CATEGORYKEY) REFERENCES  DIM_CATEGORY (CATEGORYKEY)
ON DELETE NO ACTION,

CONSTRAINT FK_DIM_REVENUE_REFION FOREIGN KEY(REGIONKEY) REFERENCES  DIM_REGION (REGIONKEY)
ON DELETE NO ACTION,

CONSTRAINT FK_DIM_REVENUE_DATE FOREIGN KEY(DATEKEY) REFERENCES  DIM_DATE (DATEKEY)
ON DELETE NO ACTION,

CONSTRAINT PK_FACT_REVENUE PRIMARY KEY(MOVIEKEY,DVDKEY,CATEGORYKEY, REGIONKEY,DATEKEY )
);
use SakilaDBS
DROP TABLE FACT_RENTDVD_ACTOR

CREATE TABLE FACT_RENTDVD_ACTOR
(

ACTORKEY INT  NOT NULL,
CATEGORYKEY INT NOT NULL,
DATEKEY INT NOT NULL,
TIMESRENTED INT NOT NULL,
DOLLARRENT MONEY,

CONSTRAINT PK_FACT_RENTDVD_ACTOR PRIMARY KEY(ACTORKEY, DATEKEY, CATEGORYKEY),


CONSTRAINT FK_FACT_RENTDVD_ACTOR_DIMCATEGORY FOREIGN KEY(CATEGORYKEY) REFERENCES  DIM_CATEGORY(CATEGORYKEY)
ON DELETE NO ACTION,

CONSTRAINT FK_FACT_RENTDVD_ACTOR_DIMDATE FOREIGN KEY(DATEKEY) REFERENCES  DIM_DATE (DATEKEY)
ON DELETE NO ACTION,

CONSTRAINT FK_FACT_RENTDVD_ACTOR_DIMACTOR FOREIGN KEY(ACTORKEY) REFERENCES  DIM_ACTOR (ACTORKEY)
ON DELETE NO ACTION,

);

--TOTAL ACTOR MOVIES
use sakila
select  (a.first_name+' '+a.last_name) as ACTORNAME, count(fa.actor_id) as COUNT_MOVIES 
from actor a
inner join film_actor fa
on fa.actor_id = a.actor_id 
where a.actor_id=1
group by (a.first_name+' '+a.last_name) 
order by (a.first_name+' '+a.last_name)

--group by (a.first_name+' '+a.last_name) ,fa.actor_id 
--order by fa.actor_id

GO
--total actor dvds
select (a.first_name+' '+a.last_name) as actor_name,  count(i.inventory_id) AS TOTAL_ACTOR_DVDS
from actor a
inner join film_actor fa
on fa.actor_id = a.actor_id
inner join inventory i
on i.film_id = fa.film_id
where a.actor_id=1
group by (a.first_name+' '+a.last_name)
order by  (a.first_name+' '+a.last_name)


-- revenue of rent by actors
use sakila
select (a.first_name+' '+a.last_name) as actor_name,  sum(p.amount) as dollarrented 
FROM ACTor a 
inner join film_actor fa
on fa.actor_id = a.actor_id
inner join inventory i
on i.film_id = fa.film_id
inner join rental r
on r.inventory_id = i.inventory_id
inner join payment p
on p.rental_id = r.rental_id
-- a.actorId= 1 and where  year(convert(date,p.payment_date)) =2005
group by (a.first_name+' '+a.last_name)

--- actor dvd total times rented  
use sakila 
select  (a.first_name+' '+a.last_name) as ACTORNAME,    count(convert(date,r.rental_date)) AS COUNT_DVD_RENTED  

from actor a
inner join film_actor fa
on fa.actor_id = a.actor_id 
inner join film f
on f.film_id = fa.film_id
inner join inventory i
on i.film_id = fa.film_id
inner join rental r
on r.inventory_id = i.inventory_id
where a.actor_id=1
group by (a.first_name+' '+a.last_name)  
order by (a.first_name+' '+a.last_name)  

----no use count times dvd of different actors rented convert(date,r.rental_date), count(i.inventory_id) as times_rented, fa.film_id, r.rental_id , i.inventory_id,
select (a.first_name+' '+a.last_name) as actor_name, p.amount, count( convert(date,r.rental_date)) as times_rented, convert(date,r.rental_date) 
FROM ACTor a 
inner join film_actor fa
on fa.actor_id = a.actor_id
inner join inventory i
on i.film_id = fa.film_id
inner join rental r
on r.inventory_id = i.inventory_id
inner join payment p
on p.rental_id = r.rental_id
group by (a.first_name+' '+a.last_name),convert(date,r.rental_date), p.amount
order by (a.first_name+' '+a.last_name)

USE SAKILA
----- total dvds by actor category
select cat.name, (a.first_name+' '+a.last_name) as actor_name, count(distinct(i.inventory_id)) as TotalDvdsOfActorOfFilmCategory
from actor a
inner join film_actor fa
on fa.actor_id = a.actor_id

inner join film_category fc
on fc.film_id = fa.film_id


inner join inventory i
on i.film_id = fc.film_id

inner join category cat
on cat.category_id =fc.category_id


group by (a.first_name+' '+a.last_name), cat.name

-------total movies  by actor category
use sakila
select (a.first_name+' '+a.last_name) as actor, cat.name as filmcategory, count(fc.film_id) as totalMoviesofActorOfCategory
from actor a
inner join film_actor fa
on fa.actor_id = a.actor_id
inner join film_category fc
on fc.film_id = fa.film_id
inner join category cat
on cat.category_id = fc.category_id
where a.actor_id=1
group by (a.first_name+' '+a.last_name) ,cat.name  
ORDER BY  (a.first_name+' '+a.last_name)

----------------------------TSAKILA DBS TOTAL ACTOR MOVIES------
-- r done
use SakilaDBS
select da.ACTORNAME ,count(da.MOVIEID) as TOTLMOVIESBYACTOR
from DIM_ACTOR da
--where da.ACTORID=1
GROUP BY DA.ACTORNAME


----------------------------------SAKILA RENT EARNED BY FIL,M CATEGORY


SELECT DIM_CATEGORY.CATEGORYNAME, DIM_DATE.Year_, SUM(FACT_REVENUE.DOLLARRENT) AS DOLLAREARNED
FROM     FACT_REVENUE INNER JOIN
                  DIM_MOVIE ON FACT_REVENUE.MOVIEKEY = DIM_MOVIE.MOVIEKEY INNER JOIN
                  DIM_REGION ON FACT_REVENUE.REGIONKEY = DIM_REGION.REGIONKEY INNER JOIN
                  DIM_CATEGORY ON FACT_REVENUE.CATEGORYKEY = DIM_CATEGORY.CATEGORYKEY INNER JOIN
                  DIM_DATE ON FACT_REVENUE.DATEKEY = DIM_DATE.DATEKEY
GROUP BY DIM_CATEGORY.CATEGORYNAME, DIM_DATE.Year_
Order By SUM(FACT_REVENUE.DOLLARRENT) DESC

---------------------------------sakiladbs total earning by year---------------
use SakilaDBS
SELECT  DIM_DATE.Year_, SUM(FACT_REVENUE.DOLLARRENT) AS DOLLAREARNED
FROM     FACT_REVENUE INNER JOIN
                  DIM_MOVIE ON FACT_REVENUE.MOVIEKEY = DIM_MOVIE.MOVIEKEY INNER JOIN
                  DIM_REGION ON FACT_REVENUE.REGIONKEY = DIM_REGION.REGIONKEY INNER JOIN
                  DIM_CATEGORY ON FACT_REVENUE.CATEGORYKEY = DIM_CATEGORY.CATEGORYKEY INNER JOIN
                  DIM_DATE ON FACT_REVENUE.DATEKEY = DIM_DATE.DATEKEY
GROUP BY DIM_DATE.Year_ 

-----------------------------------------------------------------
------------------------------SAKILA DBS TOTAL ACTOR  MOVIES BY CATEGORYCAT------------------
--R done

USE SakilaDBS
SELECT da.ACTORNAME, dc.CATEGORYNAME, count(dm.MOVIEID) as TotalMoviesByCateory --dm.MOVIENAME 
from DIM_ACTOR da
inner join DIM_MOVIE dm
on dm.MOVIEID = da.MOVIEID
inner join DIM_CATEGORY dc
on dc.CATEGORYNAME= dm.CATEGORY 
--where da.ACTORID =1 --and dc.CATEGORYNAME='Family'
group by da.ACTORNAME, dc.CATEGORYNAME
order by da.ACTORNAME

-----------------------------------------SAKILA DBS TOTAL ACTOR DVDS--------
--r done
use SakilaDBS
SELECT da.ACTORNAME, count(dd.DVDID)
from DIM_ACTOR da
inner join DIM_MOVIE dm
on dm.MOVIEID = da.MOVIEID
inner join DIM_DVD dd
on dd.MOVIEID = dm.MOVIEID

group by da.ACTORNAME
order by da.ACTORNAME


----------------------------------ACTORDVDSBYCATEGORY-------------
use SakilaDBS
select da.actorname , dc.CATEGORYNAME, count(dd.DVDID)  as TotalDvdsByCategory
from DIM_ACTOR da
inner join DIM_MOVIE dm
on dm.MOVIEID = da.MOVIEID
inner join DIM_CATEGORY dc
on dc.CATEGORYNAME = dm.CATEGORY
inner join DIM_DVD dd
on dd.MOVIEID =dm.MOVIEID
where da.ACTORID=2
group by da.actorname , dc.CATEGORYNAME

--------------------------------------DBSAKILATOTALDVDSBYMOVIES---------
select  dm.MOVIENAME, count(dd.DVDID) as totalDvds
from DIM_MOVIE dm
inner join DIM_DVD dd
on dd.MOVIEID = dm.MOVIEID
group by dm.MOVIENAME

---------------RENT AND DVD SOLD BY ACTOR CATEGORY year--
SELECT DIM_ACTOR.ACTORNAME, DIM_CATEGORY.CATEGORYNAME, DIM_DATE.Year_, SUM(FACT_RENTDVD_ACTOR.TIMESRENTED) AS TIMES_DVDS_RENTED , SUM(FACT_RENTDVD_ACTOR.DOLLARRENT) AS TOTAL_RENT_
FROM     DIM_ACTOR INNER JOIN
                  FACT_RENTDVD_ACTOR ON DIM_ACTOR.ACTORKEY = FACT_RENTDVD_ACTOR.ACTORKEY INNER JOIN
                  DIM_CATEGORY ON FACT_RENTDVD_ACTOR.CATEGORYKEY = DIM_CATEGORY.CATEGORYKEY INNER JOIN
                  DIM_DATE ON FACT_RENTDVD_ACTOR.DATEKEY = DIM_DATE.DATEKEY
GROUP BY DIM_ACTOR.ACTORNAME, DIM_CATEGORY.CATEGORYNAME, DIM_DATE.Year_

----------------------- sakiladbs  no of dvd rented per year by category
select dc.CATEGORYNAME , dd.Year_, count(fr.DVDKEY) as NOOFDVDRENTED
 from DIM_CATEGORY dc
 inner join FACT_REVENUE fr
 on fr.CATEGORYKEY = dc.CATEGORYKEY
 inner join DIM_DATE dd
 on dd.DATEKEY = fr.DATEKEY
 group by dc.CATEGORYNAME , dd.Year_

 -------------------------------- sakiladbs revenue by date 
 use SakilaDBS
 select dd.FullDate, sum(fr.DOLLARRENT)
 from FACT_REVENUE fr
 inner join DIM_DATE dd
 on dd.DATEKEY= fr.DATEKEY
 group by dd.FullDate

-------------------------------------------------------------------------
------dollar earned and times_rented by actor-category films count(convert(date,r.rental_date)) as times_rented, convert(date,r.rental_date) date_rented,
use sakila
select cat.name as categoryname,(a.first_name +' '+a.last_name) as actorname, convert(date,(r.rental_date)) as date_rented,sum(p.amount) as rentIncome,
count(convert(date,r.rental_date)) as times_rented  
FROM category cat
inner join film_category fc
on fc.category_id = cat.category_id
inner join film f
on f.film_id = fc.film_id
inner join film_actor fa
on fa.film_id = f.film_id
inner join actor a
on a.actor_id = fa.actor_id
inner join inventory i
on i.film_id = fa.film_id
inner join rental r
on r.inventory_id = i.inventory_id
inner join payment p
on p.rental_id = r.rental_id
group by cat.name ,(a.first_name +' '+a.last_name) ,convert (date,r.rental_date)

-----------------test
--- final fact 2 dvd rent by date and count rented
---,count(distinct(fa.film_id)) as total_films, count(distinct(i.inventory_id)) as total_dvds, 

select 
(a.first_name+' '+a.last_name) as actor_name ,
count(convert(date,r.rental_date)) as times_rented,
convert(date,r.rental_date) date_rented,
sum(p.amount) as dollarrented 

FROM ACTor a 

inner join film_actor fa
on fa.actor_id = a.actor_id
inner join inventory i
on i.film_id = fa.film_id
inner join rental r
on r.inventory_id = i.inventory_id
inner join payment p
on p.rental_id = r.rental_id
where a.actor_id=1
group by (a.first_name+' '+a.last_name),convert(date,r.rental_date)
--, 



----------------------fact 1 revenue
--selecting total rent by movies -,  
select f.title, i.inventory_id as DvdID ,convert(date,r.rental_date) as rented_date, ct.city , co.country, count(convert(date,r.rental_date)) as times_dvd_rented, sum ( p.amount) as dollarRented 
from film f
inner join inventory i 
on i.film_id = f.film_id
inner join rental r
on r.inventory_id = i.inventory_id
inner join payment p
on p.rental_id = r.rental_id
inner join customer c
on c.customer_id = r.customer_id 
inner join [dbo].[address] a
on a.address_id = c.address_id
inner join city ct
on ct.city_id = a.city_id
inner join country co
on co.country_id = ct.country_id
where f.film_id=1
group by f.title, i.inventory_id, convert(date,r.rental_date), ct.city , co.country
order by f.title

--,p.amount , 


--qury fact 1 final
use sakila
select f.title, i.inventory_id as DvdId , cat.name, convert(date,r.rental_date) as rented_date, ct.city , co.country, count(convert(date,r.rental_date)) as count_dvd_rented, sum ( p.amount) as dollarRented 
from film f
inner join film_category fc
on fc.film_id = f.film_id
inner join category cat
on cat.category_id = fc.category_id
inner join inventory i 
on i.film_id = f.film_id
inner join rental r
on r.inventory_id = i.inventory_id
inner join payment p
on p.rental_id = r.rental_id
inner join customer c
on c.customer_id = r.customer_id 
inner join [dbo].[address] a
on a.address_id = c.address_id
inner join city ct
on ct.city_id = a.city_id
inner join country co
on co.country_id = ct.country_id
group by f.title, cat.name, i.inventory_id ,convert(date,r.rental_date), ct.city , co.country
order by f.title
----times_rented
select f.title, count(r.rental_date) as times_rented
from film f
inner join inventory i 
on i.film_id = f.film_id
inner join rental r
on r.inventory_id = i.inventory_id
group by f.title
order by f.title
----total dvds of each movies
select f.title, count(i.inventory_id) as total_dvds
from film f
inner join inventory i 
on i.film_id = f.film_id
group by f.title
order by f.title
---- total rent for each movies
select f.title, sum(p.amount) as dollar_rent
from film f
inner join inventory i 
on i.film_id = f.film_id
inner join rental r
on r.inventory_id = i.inventory_id
inner join payment p
on p.rental_id = r.rental_id
---where year(CONVERT(date,p.payment_date)) =2006
group by f.title
order by f.title
--- rent dollar by date
select f.title, sum(p.amount) as dollar_rent, convert (date,r.rental_date) as date_rented
from film f
inner join inventory i 
on i.film_id = f.film_id
inner join rental r
on r.inventory_id = i.inventory_id
inner join payment p
on p.rental_id = r.rental_id
group by f.title,convert (date,r.rental_date)
order by f.title

------------------ neo4j tally
USE SakilaDBS
  select dd.FullDate, dm.MOVIENAME, dc.CATEGORYNAME, dr.COUNTRY 
  from DIM_MOVIE dm
  inner join FACT_REVENUE fr
  on fr.MOVIEKEY= dm.MOVIEKEY
  inner join DIM_CATEGORY dc
  on dc.CATEGORYKEY= fr.CATEGORYKEY
  inner join DIM_REGION dr
  on dr.REGIONKEY = fr.REGIONKEY
  inner join DIM_DATE dd
  on dd.DATEKEY = fr.DATEKEY
  where dm.MOVIEKEY =1
  
